Icons-50 Dataset README

The subclasses we held out for subtype robustness are as follows,
"small_airplane", "top_with_upwards_arrow_above", "soccer_ball", "duck", "hatching_chick", "crossed_swords",
"passenger_ship", "ledger", "books", "derelict_house_building", "convenience_store", "rabbit_face",
"cartwheel_type_6", "mantelpiece_clock", "watch", "sun_behind_cloud_with_rain", "wine_glass",
"face_throwing_a_kiss", "e_mail_symbol", "family_man_boy", "family_man_girl", "family_man_boy_boy",
"family_man_girl_boy", "family_man_girl_girl", "monorail", "leopard", "chequered_flag", "tulip", "womans_sandal",
"victory_hand", "womans_hat", "broken_heart", "unified_ideograph_5408", "circled_ideograph_accept",
"closed_lock_with_key", "open_mailbox_with_lowered_flag", "shark", "military_medal", "banknote_with_dollar_sign",
"monkey", "crescent_moon", "mount_fuji", "mobile_phone_off", "no_smoking_symbol", "glowing_star", "evergreen_tree",
"umbrella_with_rain_drops", "racing_car", "factory_worker", "pencil"

@article{hendrycks2018robustness,
  title={Benchmarking Neural Network Robustness to Common Corruptions and Surface Variations},
  author={Dan Hendrycks and Thomas Dietterich},
  year={2018}
}

